<?php
// This file was auto-generated from sdk-root/src/data/sagemaker-metrics/2022-09-30/paginators-1.json
return [ 'pagination' => [],];
