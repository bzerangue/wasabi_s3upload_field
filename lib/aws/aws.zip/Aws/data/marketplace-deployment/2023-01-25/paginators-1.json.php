<?php
// This file was auto-generated from sdk-root/src/data/marketplace-deployment/2023-01-25/paginators-1.json
return [ 'pagination' => [],];
