<?php
// This file was auto-generated from sdk-root/src/data/data.iot/2015-05-28/paginators-1.json
return [ 'pagination' => [ 'ListRetainedMessages' => [ 'input_token' => 'nextToken', 'limit_key' => 'maxResults', 'output_token' => 'nextToken', 'result_key' => 'retainedTopics', ], ],];
