<?php
// This file was auto-generated from sdk-root/src/data/monitoring/2010-08-01/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [ [ 'operationName' => 'ListMetrics', 'input' => [ 'Namespace' => 'AWS/EC2', ], 'errorExpectedFromService' => false, ], [ 'operationName' => 'SetAlarmState', 'input' => [ 'AlarmName' => 'abc', 'StateValue' => 'mno', 'StateReason' => 'xyz', ], 'errorExpectedFromService' => true, ], ],];
