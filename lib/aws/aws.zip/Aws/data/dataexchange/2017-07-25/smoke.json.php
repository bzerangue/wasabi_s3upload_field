<?php
// This file was auto-generated from sdk-root/src/data/dataexchange/2017-07-25/smoke.json
return [ 'version' => 1, 'defaultRegion' => 'us-west-2', 'testCases' => [],];
