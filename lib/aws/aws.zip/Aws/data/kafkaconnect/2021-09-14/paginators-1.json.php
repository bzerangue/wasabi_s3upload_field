<?php
// This file was auto-generated from sdk-root/src/data/kafkaconnect/2021-09-14/paginators-1.json
return [ 'pagination' => [ 'ListConnectors' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'connectors', ], 'ListCustomPlugins' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'customPlugins', ], 'ListWorkerConfigurations' => [ 'input_token' => 'nextToken', 'output_token' => 'nextToken', 'limit_key' => 'maxResults', 'result_key' => 'workerConfigurations', ], ],];
